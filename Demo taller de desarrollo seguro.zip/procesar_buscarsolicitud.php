<?php
$id = $_GET['id'];

// Vulnerabilidad LFI
$file = "solicitudes/" . $id . ".txt";

if (file_exists($file)) {
    echo nl2br(file_get_contents($file));
} else {
    echo "Solicitud no encontrada";
}
?>
