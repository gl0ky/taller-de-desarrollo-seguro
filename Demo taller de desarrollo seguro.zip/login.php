<?php
$servername = "localhost";
$username = "root";
$password = "150201";
$dbname = "vulnearable_db";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$usuario = $_POST['usuario'];
$password = $_POST['password'];

// Consulta SQL vulnerable a inyección SQL
$sql = "SELECT * FROM users WHERE usuario='$usuario' AND password='$password' OR 1=1 -- -";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    header("Location: home.html");
} else {
    echo "Usuario o contraseña incorrectos";
}

$conn->close();
?>
