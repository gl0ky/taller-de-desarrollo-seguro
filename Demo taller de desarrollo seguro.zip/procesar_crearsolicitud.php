<?php
$id = $_POST['id'];
$titulo = $_POST['titulo'];
$descripcion = $_POST['descripcion'];

// Crear la carpeta 'solicitudes' si no existe
if (!file_exists('solicitudes')) {
    mkdir('solicitudes', 0777, true);
}

// Guardar la solicitud en un archivo
$file = fopen("solicitudes/$id.txt", "w");
fwrite($file, "Título: $titulo\nDescripción: $descripcion");
fclose($file);

echo "Solicitud creada exitosamente";
?>

