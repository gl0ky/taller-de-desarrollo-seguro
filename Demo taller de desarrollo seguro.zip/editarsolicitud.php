<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Solicitud</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Editar Solicitud</h2>
    <form action="procesar_editarsolicitud.php" method="post">
        <label for="id">ID de la Solicitud:</label>
        <input type="text" id="id" name="id" required>
        <br>
        <label for="titulo">Nuevo Título:</label>
        <input type="text" id="titulo" name="titulo" required>
        <br>
        <label for="descripcion">Nueva Descripción:</label>
        <textarea id="descripcion" name="descripcion" required></textarea>
        <br>
        <input type="submit" value="Editar Solicitud">
    </form>
</body>
</html>
