<?php
$id = $_POST['id'];
$titulo = $_POST['titulo'];
$descripcion = $_POST['descripcion'];

$file = "solicitudes/$id.txt";

if (file_exists($file)) {
    $file = fopen($file, "w");
    fwrite($file, "Título: $titulo\nDescripción: $descripcion");
    fclose($file);
    echo "Solicitud editada exitosamente";
} else {
    echo "Solicitud no encontrada";
}
?>
